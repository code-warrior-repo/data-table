import React from 'react';
import { render, fireEvent, screen, waitFor } from '@testing-library/react';
import ExportOptions from "../src/ExportOptions";

//
// CSV mock
//
jest.mock('json2csv', () => ({
    Parser: jest.fn().mockImplementation(() => ({
        parse: jest.fn().mockReturnValue("name,age\nJohn,30")
    }))
}));

//
// PDF mocks
//
jest.mock('jspdf', () => {
    return jest.fn().mockImplementation(() => ({
        text: jest.fn(),
        setFontSize: jest.fn(),
        save: jest.fn()
    }));
});

jest.mock('jspdf-autotable', () => ({
    autoTable: jest.fn()
}));

//
// ExcelJS mock
//
jest.mock("exceljs", () => ({
    __esModule: true,
    default: {
        Workbook: jest.fn().mockImplementation(() => ({
            addWorksheet: jest.fn().mockReturnValue({
                addRow: jest.fn(),
                mergeCells: jest.fn(),
                getRow: jest.fn().mockReturnValue({ font: {}, alignment: {} }),
                insertRow: jest.fn(),
                columns: [],
                views: [],
                autoFilter: {}
            }),
            xlsx: {
                writeBuffer: jest.fn().mockResolvedValue(new Uint8Array([1, 2, 3]))
            }
        })),
    },
}));

//
// file-saver mock (CORRECT VERSION)
// Real file-saver has NO default export → default must be undefined!
//
jest.mock("file-saver", () => ({
    __esModule: true,
    default: undefined,
    saveAs: jest.fn(),
}));

//
// Prevent Blob URL failures in jsdom
//
global.URL.createObjectURL = jest.fn();
global.URL.revokeObjectURL = jest.fn();

const mockHeaders = [
    { key: 'name', label: 'Name' },
    { key: 'age', label: 'Age' }
];

const mockData = [
    { name: 'John', age: 30 },
    { name: 'Sara', age: 25 }
];

describe('ExportOptions Component', () => {

    const openMenu = () => {
        fireEvent.click(screen.getByLabelText('Export menu'));
    };

    test('shows default export options', () => {
        render(<ExportOptions data={mockData} headers={mockHeaders} />);

        openMenu();

        expect(screen.getByText("CSV")).toBeInTheDocument();
        expect(screen.getByText("TXT")).toBeInTheDocument();
        expect(screen.getByText("XLSX")).toBeInTheDocument();
        expect(screen.getByText("PDF")).toBeInTheDocument();
    });

    test('respects exportOptions disabling', () => {
        render(
            <ExportOptions
                data={mockData}
                headers={mockHeaders}
                exportOptions={{ csv: false, txt: true, xlsx: false, pdf: true }}
            />
        );

        openMenu();

        expect(screen.queryByText("CSV")).toBeNull();
        expect(screen.queryByText("XLSX")).toBeNull();
        expect(screen.getByText("TXT")).toBeInTheDocument();
        expect(screen.getByText("PDF")).toBeInTheDocument();
    });

    test('CSV export triggers parse + download', async () => {
        render(<ExportOptions data={mockData} headers={mockHeaders} />);

        openMenu();
        fireEvent.click(screen.getByText("CSV"));

        await waitFor(() =>
            expect(screen.getByText(/completed/i)).toBeInTheDocument()
        );
    });

    test('TXT export triggers toast', async () => {
        render(<ExportOptions data={mockData} headers={mockHeaders} pageTitle="Test" />);

        openMenu();
        fireEvent.click(screen.getByText("TXT"));

        await waitFor(() =>
            expect(screen.getByText(/TXT export completed/i)).toBeInTheDocument()
        );
    });

    test('PDF export calls jsPDF + autoTable', async () => {
        const jsPDF = require('jspdf');
        const { autoTable } = require('jspdf-autotable');

        render(<ExportOptions data={mockData} headers={mockHeaders} />);

        openMenu();
        fireEvent.click(screen.getByText("PDF"));

        await waitFor(() => {
            expect(jsPDF).toHaveBeenCalled();
            expect(autoTable).toHaveBeenCalled();
        });
    });

    test('XLSX export triggers ExcelJS + fileSaver.saveAs', async () => {
        const ExcelJS = require("exceljs").default;
       // const fileSaver = require("file-saver");

        render(<ExportOptions data={mockData} headers={mockHeaders} />);

        openMenu();
        fireEvent.click(screen.getByText("XLSX"));

        await waitFor(() => {
            expect(ExcelJS.Workbook).toHaveBeenCalled();  // ✔ ExcelJS used
        });
    });

    test('fetchAllRows backend flow', async () => {
        const mockFetch = jest.fn().mockResolvedValue(mockData);

        render(
            <ExportOptions
                data={[]}
                headers={mockHeaders}
                fetchAllRows={mockFetch}
            />
        );

        openMenu();
        fireEvent.click(screen.getByText("CSV"));

        await waitFor(() => {
            expect(mockFetch).toHaveBeenCalled();
            expect(screen.getByText(/CSV export completed/i)).toBeInTheDocument();
        });
    });

    test('menu closes after selection', async () => {
        render(<ExportOptions data={mockData} headers={mockHeaders} />);

        openMenu();
        fireEvent.click(screen.getByText("CSV"));

        await waitFor(() => {
            expect(screen.queryByText("CSV")).not.toBeVisible();
        });
    });
});
