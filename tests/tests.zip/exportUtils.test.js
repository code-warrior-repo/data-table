import {buildHeaderAccessors, sanitizePlainText, timestamp } from "../src/exportUtils";
import {getByPath, toDisplayString} from "../src/util";

jest.mock('../../../src/app/components/DynamicTable/util', () => {
    const toDisplayString = jest.fn((val /*, fmt */) => {
        // simple pass-through formatting for tests
        if (val == null) return '';
        return String(val);
    });

    // simple getByPath implementation for tests
    const getByPath = (obj, path) => {
        if (!path) return undefined;
        return path.split('.').reduce((acc, key) => (acc == null ? acc : acc[key]), obj);
    };

    return { getByPath, toDisplayString };
});


describe('exportUtils', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('buildHeaderAccessors', () => {
        test('composite column: joins parts with separator and applies suffix', () => {
            const headers = [{
                key: 'fullName',
                label: 'Full Name',
                fields: ['name.first', 'name.last'],
                separator: ' ',
                suffix: '!',
            }];

            const [{ key, label, getValue }] = buildHeaderAccessors(headers);

            expect(key).toBe('fullName');
            expect(label).toBe('Full Name');

            const row = { name: { first: 'John', last: 'Doe' } };
            const value = getValue(row);

            expect(value).toBe('John Doe!');
            // toDisplayString called once per field, with no dateFormat param
            expect(toDisplayString).toHaveBeenCalledTimes(2);
            expect(toDisplayString).toHaveBeenNthCalledWith(1, 'John');
            expect(toDisplayString).toHaveBeenNthCalledWith(2, 'Doe');
        });

        test('single column: passes dateFormat and applies suffix', () => {
            const headers = [{
                field: 'createdAt',
                key: 'createdAt',
                label: 'Created',
                dateFormat: 'YYYY-MM-DD',
                suffix: ' UTC',
            }];

            const [{ key, label, getValue }] = buildHeaderAccessors(headers);

            expect(key).toBe('createdAt');
            expect(label).toBe('Created');

            const row = { createdAt: '2024-01-02T03:04:05Z' };
            const value = getValue(row);

            // Our mock toDisplayString returns the raw string, then suffix is added
            expect(value).toBe('2024-01-02T03:04:05Z UTC');
            expect(toDisplayString).toHaveBeenCalledTimes(1);
            expect(toDisplayString).toHaveBeenCalledWith('2024-01-02T03:04:05Z', 'YYYY-MM-DD');
        });

        test('falls back label to key when label is missing', () => {
            const headers = [{ field: 'status', key: 'status' }];
            const [{ key, label }] = buildHeaderAccessors(headers);
            expect(key).toBe('status');
            expect(label).toBe('status');
        });

        test('no-op accessor when no key/field provided', () => {
            const headers = [{}]; // neither key nor field
            const [{ key, label, getValue }] = buildHeaderAccessors(headers);

            expect(key).toBe('');
            expect(label).toBe('');
            expect(getValue({})).toBe('');
            // Should not attempt any path/format calls
            expect(toDisplayString).not.toHaveBeenCalled();
        });

        test('separator defaults to empty string', () => {
            const headers = [{
                key: 'code',
                fields: ['a', 'b', 'c'], // no separator provided
            }];

            const [{ getValue }] = buildHeaderAccessors(headers);
            const row = { a: 'A', b: 'B', c: 'C' };
            expect(getValue(row)).toBe('ABC');
        });

        test('handles null/undefined values safely in composite', () => {
            const headers = [{
                key: 'maybeFullName',
                fields: ['name.first', 'name.middle', 'name.last'],
                separator: ' ',
            }];

            const [{ getValue }] = buildHeaderAccessors(headers);
            const row = { name: { first: 'John', last: 'Doe' } };

            // Our mock toDisplayString returns '' for null/undefined
            expect(getValue(row)).toBe('John  Doe'); // middle missing becomes ''
        });
    });

    describe('sanitizePlainText', () => {
        test('replaces tabs and newlines with spaces', () => {
            const input = 'Line1\tLine2\r\nLine3\nLine4';
            const output = sanitizePlainText(input);
            expect(output).toBe('Line1 Line2 Line3 Line4');
        });

        test('handles null/undefined input', () => {
            expect(sanitizePlainText(null)).toBe('');
            expect(sanitizePlainText(undefined)).toBe('');
        });
    });

    describe('timestamp', () => {
        test('formats as MMDDYYYYHHMMSS in UTC', () => {
            const d = new Date(Date.UTC(2024, 0, 2, 3, 4, 5)); // Jan 2, 2024 03:04:05 UTC
            const ts = timestamp(d);
            expect(ts).toBe('01022024030405');
        });
    });

    // Utility behavior sanity checks (from our mock)
    describe('util mocks', () => {
        test('getByPath resolves nested paths', () => {
            const obj = { a: { b: { c: 42 } } };
            expect(getByPath(obj, 'a.b.c')).toBe(42);
            expect(getByPath(obj, 'a.b.x')).toBeUndefined();
        });
    });
});