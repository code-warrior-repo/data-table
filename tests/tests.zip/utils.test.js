import {
    getByPath,
    isIsoDateString,
    toDisplayString,
    sortData
} from "../src/util";  // update import path
import { formatDate } from "../src/utils/formatDate";

jest.mock("../src/utils/formatDate", () => ({
    formatDate: jest.fn(() => "FormattedDate")
}));

describe("Utility Functions", () => {

    /* ---------------------------------------------------
     * getByPath
     * --------------------------------------------------- */
    describe("getByPath", () => {
        test("returns nested value", () => {
            const obj = { a: { b: { c: 10 } } };
            expect(getByPath(obj, "a.b.c")).toBe(10);
        });

        test("returns undefined if any segment is missing", () => {
            const obj = { a: {} };
            expect(getByPath(obj, "a.b.c")).toBeUndefined();
        });

        test("returns undefined for null/empty path", () => {
            expect(getByPath({ a: 1 }, "")).toBeUndefined();
            expect(getByPath(null, "a")).toBeUndefined();
        });
    });

    /* ---------------------------------------------------
     * isIsoDateString
     * --------------------------------------------------- */
    describe("isIsoDateString", () => {
        test("valid ISO formats", () => {
            expect(isIsoDateString("2024-01-10")).toBe(true);
            expect(isIsoDateString("2024-01-10T12:00:00Z")).toBe(true);
            expect(isIsoDateString("2024-01-10 12:30")).toBe(true);
        });

        test("invalid ISO formats", () => {
            expect(isIsoDateString("01-10-2024")).toBe(false);
            expect(isIsoDateString("invalid")).toBe(false);
            expect(isIsoDateString(123)).toBe(false);
        });
    });

    /* ---------------------------------------------------
     * toDisplayString
     * --------------------------------------------------- */
    describe("toDisplayString", () => {
        test("returns empty string for null/undefined", () => {
            expect(toDisplayString(null)).toBe("");
            expect(toDisplayString(undefined)).toBe("");
        });

        test("formats Date objects", () => {
            const d = new Date();
            expect(toDisplayString(d)).toBe("FormattedDate");
            expect(formatDate).toHaveBeenCalled();
        });

        test("formats ISO dates", () => {
            expect(toDisplayString("2024-01-10")).toBe("FormattedDate");
        });

        test("returns string for numbers and booleans", () => {
            expect(toDisplayString(123)).toBe("123");
            expect(toDisplayString(true)).toBe("true");
        });

        test("returns original string for non-date strings", () => {
            expect(toDisplayString("hello")).toBe("hello");
        });
    });

    /* ---------------------------------------------------
     * sortData
     * --------------------------------------------------- */
    describe("sortData", () => {
        const data = [
            { name: "b", age: 40, date: "2024-01-02" },
            { name: "a", age: 20, date: "2024-01-01" },
            { name: "c", age: 30, date: "2024-01-03" }
        ];

        test("returns original array if empty", () => {
            expect(sortData([], {})).toEqual([]);
        });

        /* -------- Single Column -------- */
        test("sorts by single column asc", () => {
            const sorted = sortData(data, { orderBy: "name", order: "asc" });
            expect(sorted.map(x => x.name)).toEqual(["a", "b", "c"]);
        });

        test("sorts by single column desc", () => {
            const sorted = sortData(data, { orderBy: "age", order: "desc" });
            expect(sorted.map(x => x.age)).toEqual([40, 30, 20]);
        });

        test("sorts ISO date strings correctly", () => {
            const sorted = sortData(data, { orderBy: "date", order: "asc" });
            expect(sorted.map(x => x.date)).toEqual([
                "2024-01-01",
                "2024-01-02",
                "2024-01-03"
            ]);
        });

        /* -------- Multi Column -------- */
        test("sorts by multiple columns", () => {
            const multiData = [
                { name: "b", age: 20 },
                { name: "a", age: 30 },
                { name: "a", age: 10 }
            ];

            const sorted = sortData(multiData, {
                selectedColumns: [
                    { field: "name", order: "asc" },
                    { field: "age", order: "asc" }
                ]
            });

            expect(sorted).toEqual([
                { name: "a", age: 10 },
                { name: "a", age: 30 },
                { name: "b", age: 20 }
            ]);
        });

        test("does not mutate original array", () => {
            const clone = [...data];
            sortData(data, { orderBy: "name" });
            expect(data).toEqual(clone);
        });
    });
});