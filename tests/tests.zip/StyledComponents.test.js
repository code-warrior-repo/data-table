import React from 'react';
import { render, screen } from '@testing-library/react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import TableBody from '@mui/material/TableBody';
import Table from '@mui/material/Table';
import TableRow from '@mui/material/TableRow';
import {StyledTableCell, StyledTableRow} from "../src/StyledComponents";

// A simple theme to test styling
const theme = createTheme({
    palette: {
        primary: { main: '#1976d2' },
        common: { white: '#ffffff' },
        action: { hover: '#f5f5f5' },
    },
});

const renderWithTheme = (ui) =>
    render(<ThemeProvider theme={theme}>{ui}</ThemeProvider>);

describe('StyledTableCell', () => {
    it('applies primary background and white text for header cells', () => {
        renderWithTheme(
            <Table>
                <TableBody>
                    <TableRow>
                        <StyledTableCell variant="head">Header</StyledTableCell>
                    </TableRow>
                </TableBody>
            </Table>
        );
        const cell = screen.getByText('Header');

        const styles = getComputedStyle(cell);
        expect(styles.backgroundColor).toBe('rgb(25, 118, 210)'); // #0A3D0F - Dark green
        expect(styles.color).toBe('rgb(255, 255, 255)'); // white
    });

    it('applies font size 0.875rem for body cells', () => {
        renderWithTheme(
            <Table>
                <TableBody>
                    <TableRow>
                        <StyledTableCell>Body</StyledTableCell>
                    </TableRow>
                </TableBody>
            </Table>
        );
        const cell = screen.getByText('Body');

        const styles = getComputedStyle(cell);
        expect(styles.fontSize).toBe('14px'); // 0.875rem = 14px
    });
});

describe('StyledTableRow', () => {
    it('applies hover color for odd rows', () => {
        renderWithTheme(
            <Table>
                <TableBody>
                    <StyledTableRow>
                        <StyledTableCell>Odd Row</StyledTableCell>
                    </StyledTableRow>
                </TableBody>
            </Table>
        );

        const row = screen.getByText('Odd Row').closest('tr');
        const styles = getComputedStyle(row);

        expect(styles.backgroundColor).toBe('rgb(245, 245, 245)'); // theme.action.hover
    });

    it('no border on last row', () => {
        renderWithTheme(
            <Table>
                <TableBody>
                    <StyledTableRow>
                        <StyledTableCell>Row 1</StyledTableCell>
                    </StyledTableRow>
                    <StyledTableRow>
                        <StyledTableCell>Last Row</StyledTableCell>
                    </StyledTableRow>
                </TableBody>
            </Table>
        );

        const lastCell = screen.getByText('Last Row');
        const styles = getComputedStyle(lastCell);

        // Last row should have border: 0
        expect(styles.borderWidth).toBe('0px');
    });
});