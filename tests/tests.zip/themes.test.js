import { themes } from '../src/themes'; // Adjust path

describe('themes object', () => {
    it('should contain all expected theme keys', () => {
        expect(Object.keys(themes)).toEqual([
            'default',
            'grey',
            'blue',
            'light',
        ]);
    });

    it('should create valid MUI theme objects', () => {
        Object.values(themes).forEach(theme => {
            // MUI themes created with createTheme always have a palette + typography, etc.
            expect(theme).toHaveProperty('palette');
            expect(theme.palette).toHaveProperty('primary');
            expect(theme.palette).toHaveProperty('secondary');
        });
    });

    it('default theme colors are correct', () => {
        const t = themes.default;
        expect(t.palette.primary.main).toBe('#008000');
        expect(t.palette.secondary.main).toBe('#ff4081');
    });

    it('grey theme colors are correct', () => {
        const t = themes.grey;
        expect(t.palette.primary.main).toBe('#9e9e9e');
        expect(t.palette.secondary.main).toBe('#bdbdbd');
    });

    it('blue theme colors are correct', () => {
        const t = themes.blue;
        expect(t.palette.primary.main).toBe('#1976d2');
        expect(t.palette.secondary.main).toBe('#ff4081');
    });

    it('light theme should use light mode', () => {
        const t = themes.light;
        expect(t.palette.mode).toBe('light');
        expect(t.palette.primary.main).toBe('#90caf9');
        expect(t.palette.secondary.main).toBe('#f48fb1');
    });
});