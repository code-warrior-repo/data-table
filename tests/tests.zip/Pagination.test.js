import React from 'react';
import { render } from '@testing-library/react';
import { TablePagination } from '@mui/material';
import Pagination from "../src/Pagination";

// Spy on the MUI TablePagination component
jest.mock('@mui/material/TablePagination', () => {
    return {
        __esModule: true,
        default: jest.fn((props) => {
            return (
                <div data-testid="table-pagination-mock">
                    {JSON.stringify(props)}
                </div>
            );
        }),
    };
});


describe('Pagination Component', () => {
    const defaultProps = {
        count: 100,
        rowsPerPage: 10,
        page: 1,
        onPageChange: jest.fn(),
        onRowsPerPageChange: jest.fn(),
        initialRowsPerPage: 10,
    };

    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('renders without crashing', () => {
        render(<Pagination {...defaultProps} />);

        expect(TablePagination).toHaveBeenCalledTimes(1);

        // Count & Page Props
        expect(TablePagination.mock.calls[0][0].count).toBe(100);
        expect(TablePagination.mock.calls[0][0].page).toBe(1);
        expect(TablePagination.mock.calls[0][0].rowsPerPage).toBe(10);
    });

    test('includes correct rowsPerPageOptions', () => {
        render(<Pagination {...defaultProps} />);

        const props = TablePagination.mock.calls[0][0];
        expect(props.rowsPerPageOptions).toEqual([
            10,
            20,
            30,
            { value: -1, label: 'All' },
        ]);
    });

    test('calls onPageChange when triggered', () => {
        render(<Pagination {...defaultProps} />);

        const props = TablePagination.mock.calls[0][0];

        // Simulate MUI callback
        props.onPageChange({}, 2);

        expect(defaultProps.onPageChange).toHaveBeenCalledWith({}, 2);
    });

    test('calls onRowsPerPageChange when triggered', () => {
        render(<Pagination {...defaultProps} />);

        const props = TablePagination.mock.calls[0][0];

        const event = { target: { value: 20 } };

        props.onRowsPerPageChange(event);

        expect(defaultProps.onRowsPerPageChange).toHaveBeenCalledWith(event);
    });
});