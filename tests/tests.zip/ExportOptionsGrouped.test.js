/**
 * @jest-environment jsdom
 */

import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import ExportOptionsGrouped from "../src/ExportOptionsGrouped";

/* -------- Portal Fix -------- */
beforeAll(() => {
    document.body.innerHTML =
        '<div id="root"></div><div id="portal-root"></div>';

    const portalRoot = document.getElementById("portal-root");
    const originalCreate = document.createElement;

    document.createElement = (...args) => {
        const el = originalCreate.apply(document, args);
        if (el instanceof HTMLDivElement && !el.parentElement) {
            portalRoot.appendChild(el);
        }
        return el;
    };
});

/* -------- jsPDF MOCK -------- */
const textMock = jest.fn();
const saveMock = jest.fn();
const addPageMock = jest.fn();
const setFontMock = jest.fn();
const setFontSizeMock = jest.fn();

jest.mock("jspdf", () => ({
    __esModule: true,
    default: jest.fn().mockImplementation(() => ({
        text: textMock,
        save: saveMock,
        addPage: addPageMock,
        setFont: setFontMock,
        setFontSize: setFontSizeMock,
        lastAutoTable: { finalY: 40 },
        internal: { pageSize: { getHeight: () => 800 } }
    }))
}));

/* -------- autoTable MOCK -------- */
jest.mock("jspdf-autotable", () => ({
    autoTable: jest.fn((doc, opts) => {
        doc.lastAutoTable = { finalY: opts.startY + 20 };
    })
}));

/* -------- ExcelJS MOCK -------- */
jest.mock("exceljs", () => {
    class MockRow {
        constructor(values = []) {
            this.values = values;
            this.font = {};
            this.border = {};
            this.alignment = {};
        }
        eachCell(arg1, arg2) {
            const handler = typeof arg1 === "function" ? arg1 : arg2;
            if (typeof handler === "function") {
                handler({ alignment: {}, border: {}, fill: {} });
            }
        }
    }

    class MockWorksheet {
        constructor() {
            this.rows = [];
            this.views = [];
        }
        addRow(values = []) {
            const r = new MockRow(values);
            this.rows.push(r);
            return r;
        }
        getRow(i) {
            if (!this.rows[i - 1]) this.rows[i - 1] = new MockRow();
            return this.rows[i - 1];
        }
        mergeCells() {}
    }

    class MockWorkbook {
        constructor() {
            this.xlsx = {
                writeBuffer: jest.fn().mockResolvedValue(new ArrayBuffer(8)),
            };
        }
        addWorksheet() {
            return new MockWorksheet();
        }
    }

    return {
        __esModule: true,
        default: { Workbook: MockWorkbook },
        Workbook: MockWorkbook
    };
});

/* -------- FileSaver MOCK -------- */
const saveAsMock = jest.fn();
jest.mock("file-saver", () => ({
    __esModule: true,
    default: { saveAs: saveAsMock },
    saveAs: saveAsMock
}));

/* -------- Helper: Click Menu Item -------- */
async function clickMenuItem(label) {
    await userEvent.click(screen.getByTestId("export-test-id"));
    const item = await screen.findByText(label);
    await userEvent.click(item);
}

/* -------- Test Data -------- */
const headers = [
    { key: "division", label: "Division" },
    { key: "costCenter", label: "Cost Code" },
    { key: "totalAssociates", label: "Total" }
];

const groupedRows = [
    { isDivisionHeader: true, division: "10" },
    { division: "10", costCenter: "AAA", totalAssociates: 50 },
    { isColumnHeader: true },
    { isTotal: true, division: "10", costCenter: "Total", totalAssociates: 50 },

    { isDivisionHeader: true, division: "28" },
    { division: "28", costCenter: "BBB", totalAssociates: 100 },
    { isTotal: true, division: "28", costCenter: "Total", totalAssociates: 100 },
];

const pageTitle = "Test Report";

/* -------- TEST SUITE -------- */
describe("ExportOptionsGrouped — Compact 100% Coverage", () => {

    beforeEach(() => {
        jest.clearAllMocks();
        if (!global.URL.createObjectURL) {
            global.URL.createObjectURL = jest.fn(() => "blob:test");
        } else {
            jest.spyOn(global.URL, "createObjectURL").mockReturnValue("blob:test");
        }
    });

    test("opens export menu", async () => {
        render(<ExportOptionsGrouped groupedRows={groupedRows} headers={headers} pageTitle={pageTitle} />);
        await userEvent.click(screen.getByTestId("export-test-id"));
        expect(await screen.findByText("CSV")).toBeInTheDocument();
    });

    test("CSV export triggers Blob + createObjectURL", async () => {
        render(<ExportOptionsGrouped groupedRows={groupedRows} headers={headers} pageTitle={pageTitle} />);

        await clickMenuItem("CSV");

        expect(global.URL.createObjectURL).toHaveBeenCalled();
        expect(textMock).not.toHaveBeenCalled(); // CSV shouldn't use PDF
    });

    test("PDF export produces correct division headers", async () => {
        const jsPDFClass = require("jspdf").default;
        const pdf = jsPDFClass();

        render(<ExportOptionsGrouped groupedRows={groupedRows} headers={headers} pageTitle={pageTitle} />);

        await clickMenuItem("PDF");

        const calls = pdf.text.mock.calls.map(c => c[0]);

        expect(calls).toContain("Division: 10");
        expect(calls).toContain("Division: 28");

        expect(addPageMock).not.toHaveBeenCalled(); // No overflow in test
    });

    test("XLSX export triggers saveAs", async () => {
        render(<ExportOptionsGrouped groupedRows={groupedRows} headers={headers} pageTitle={pageTitle} />);

        await clickMenuItem("XLSX");

        await waitFor(() => {
            expect(saveAsMock).toHaveBeenCalledTimes(1);
        });
    });

    test("Preserves division order", async () => {
        render(<ExportOptionsGrouped groupedRows={groupedRows} headers={headers} pageTitle={pageTitle} />);

        await clickMenuItem("PDF");

        const pdf = require("jspdf").default();
        const calls = pdf.text.mock.calls.map(c => c[0]);

        const index10 = calls.indexOf("Division: 10");
        const index28 = calls.indexOf("Division: 28");

        expect(index10).toBeLessThan(index28);
    });

});