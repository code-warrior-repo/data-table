import React from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Table, TableHead } from '@mui/material';
import SortingHeader from "../src/SortingHeader";

// Helpful utility to render inside a table header context
const renderInTableHead = (ui) => {
    return render(
        <Table>
            <TableHead>{ui}</TableHead>
        </Table>
    );
};

describe('SortingHeader', () => {
    const headers = [
        { label: 'Name', field: 'name' },
        { label: 'Age', field: 'age' },
        { label: 'City', field: 'city' },
    ];

    const tooltipFields = {
        age: ['Age is calculated as of today', 'Format: years'],
        city: ['Primary location', 'Can be empty'],
        // name has no tooltip
    };

    const columnWidths = {
        name: 200,
        age: 80,
        city: 160,
    };

    it('marks the active sorted column and sets direction correctly', () => {
        const handleRequestSort = jest.fn();

        renderInTableHead(
            <SortingHeader
                headers={headers}
                orderBy="age"
                order="desc"
                handleRequestSort={handleRequestSort}
                tooltipFields={tooltipFields}
                columnWidths={columnWidths}
            />
        );

        // The sort label is rendered as a button with the column text as accessible name
        const ageSortButton = screen.getByRole('button', { name: /age/i });
        expect(ageSortButton).toBeInTheDocument();

        // Active state: MUI applies aria-sort on the TableCell wrapper or button
        // We can assert by checking aria-pressed or the direction attribute on the SortLabel
        // However, TableSortLabel sets aria-sort on the parent TableCell via TableHead context.
        // A more robust check: ensure the SVG icon has 'aria-hidden' and the button has data-direction.
        // Simpler: check that non-active columns default to 'asc' direction label.
        const nameSortButton = screen.getByRole('button', { name: /name/i });

        // Verify attribute `aria-sort` on the closest cell when active
        const nameCell = nameSortButton.closest('th') || nameSortButton.closest('td');

        // Non-active columns should not have aria-sort
        expect(nameCell).not.toHaveAttribute('aria-sort');
    });

    it('calls handleRequestSort with the correct field when a header is clicked', async () => {
        const user = userEvent.setup();
        const handleRequestSort = jest.fn();

        renderInTableHead(
            <SortingHeader
                headers={headers}
                orderBy="name"
                order="asc"
                handleRequestSort={handleRequestSort}
                tooltipFields={tooltipFields}
                columnWidths={columnWidths}
            />
        );

        const citySortButton = screen.getByRole('button', { name: /city/i });
        await user.click(citySortButton);

        expect(handleRequestSort).toHaveBeenCalledTimes(1);
        expect(handleRequestSort).toHaveBeenCalledWith('city');
    });

    it('renders tooltips only for fields present in tooltipFields and shows content on hover', async () => {
        jest.useFakeTimers(); // control tooltip delay
        const user = userEvent.setup({ advanceTimers: jest.advanceTimersByTime });

        const handleRequestSort = jest.fn();

        renderInTableHead(
            <SortingHeader
                headers={headers}
                orderBy="name"
                order="asc"
                handleRequestSort={handleRequestSort}
                tooltipFields={tooltipFields}
                columnWidths={columnWidths}
            />
        );

        // Age column has a tooltip (info icon present)
        const ageCell = screen.getByRole('columnheader', { name: /age/i });
        const ageInfoButton = withinCell(ageCell).getByRole('button', { name: /info/i });
        expect(ageInfoButton).toBeInTheDocument();

        // Name column does NOT have a tooltip (no info icon)
        const nameCell = screen.getByRole('columnheader', { name: /name/i });
        const nameInfoButton = queryInfoButton(nameCell);
        expect(nameInfoButton).toBeNull();

        // Hover the age info icon to show tooltip content
        await user.hover(ageInfoButton);
        jest.advanceTimersByTime(200); // allow tooltip to render

        // Tooltip content should render list items
        expect(await screen.findByText('Age is calculated as of today')).toBeInTheDocument();
        expect(screen.getByText('Format: years')).toBeInTheDocument();

    });

    it('applies column widths via style', () => {
        const handleRequestSort = jest.fn();

        renderInTableHead(
            <SortingHeader
                headers={headers}
                orderBy="name"
                order="asc"
                handleRequestSort={handleRequestSort}
                tooltipFields={{}} // none
                columnWidths={columnWidths}
            />
        );

        const nameCell = screen.getByRole('columnheader', { name: /name/i });
        const ageCell = screen.getByRole('columnheader', { name: /age/i });
        const cityCell = screen.getByRole('columnheader', { name: /city/i });

        expect(nameCell).toHaveStyle({ width: '200px' });
        expect(ageCell).toHaveStyle({ width: '80px' });
        expect(cityCell).toHaveStyle({ width: '160px' });
    });
});

/**
 * Helpers
 */
function withinCell(cell) {
    // Tooltip wraps IconButton -> InfoIcon. The IconButton does not have an accessible name by default.
    // However, MUI IconButton with an <svg> icon can be found via role="button".
    // To specifically find the info button inside a cell, we search within the cell for role="button" that is not the SortLabel button.
    const buttons = cell.querySelectorAll('button');
    if (!buttons || buttons.length === 0) {
        throw new Error('No buttons found in cell');
    }
    // First button is typically the sort label; second is the info icon
    return {
        getByRole: (_role, options) => {
            const [sortBtn, infoBtn] = buttons;
            if (options?.name) {
                // Without aria-label, the info button may not have a name; fall back to the second button
                return infoBtn || sortBtn;
            }
            return infoBtn || sortBtn;
        },
    };
}

function queryInfoButton(cell) {
    const buttons = cell.querySelectorAll('button');
    if (!buttons || buttons.length === 0) return null;
    // If there is only one button, it's the SortLabel; info button would be a second button.
    return buttons.length > 1 ? buttons[1] : null;
}