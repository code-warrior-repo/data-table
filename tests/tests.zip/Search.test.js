import React from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Search from "../src/Search";

describe('Search component', () => {
    it('renders without the TextField initially and shows the Search icon tooltip', async () => {
        jest.useFakeTimers();
        const user = userEvent.setup({ advanceTimers: jest.advanceTimersByTime });

        const handleSearchTextChange = jest.fn();
        render(<Search searchText="" handleSearchTextChange={handleSearchTextChange} />);

        // TextField should not be present initially
        expect(screen.queryByRole('textbox', { name: /search/i })).not.toBeInTheDocument();

        // There is a single IconButton; hover should reveal "Search" tooltip
        const toggleButton = screen.getByRole('button');
        await user.hover(toggleButton);
        jest.advanceTimersByTime(150); // allow tooltip to appear

        const tooltip = await screen.findByTestId('SearchIcon');
        expect(tooltip).toBeInTheDocument();

    });

});
