import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import DynamicTable from "../src/DynamicTable";

// Sample props for testing
const mockHeaders = [
    { field: 'name', label: 'Name' },
    { field: 'age', label: 'Age' },
];
const mockData = [
    { name: 'Alice', age: 30 },
    { name: 'Bob', age: 25 },
    { name: 'Charlie', age: 35 },
];

describe('DynamicTable', () => {
    it('renders table with headers and data', () => {
        render(<DynamicTable headers={mockHeaders} data={mockData} initialRowsPerPage={2}  />);

        // Check headers
        expect(screen.getByText('Name')).toBeInTheDocument();
        expect(screen.getByText('Age')).toBeInTheDocument();

        // Check data rows
        expect(screen.getByText('Alice')).toBeInTheDocument();
        expect(screen.getByText('Bob')).toBeInTheDocument();
    });

    it('handles sorting on a column', async () => {
        const user = userEvent.setup();
        const onPageChangeRequest = jest.fn();
        render(<DynamicTable
            headers={mockHeaders}
            data={mockData}
            onPageChangeRequest={onPageChangeRequest}
            orderBy="age" order="asc" />);

        // Initial order (assuming asc by default)
        const rows = screen.getAllByRole('row');
        expect(rows[1].textContent).toContain('Bob25'); // Age 25 first if sorted asc

        // Click to sort desc
        await user.click(screen.getByText('Age'));
        expect(rows[1].textContent).toContain('Charlie35'); // Age 35 first in desc
    });

    it('handles pagination', async () => {
        const user = userEvent.setup();
        render(<DynamicTable headers={mockHeaders} data={mockData} initialRowsPerPage={1} />);

        // Page 1: Alice
        expect(screen.getByText('Alice')).toBeInTheDocument();
        expect(screen.queryByText('Bob')).not.toBeInTheDocument();

        // Navigate to next page
        await user.click(screen.getByTestId(/ChevronRightIcon/i));
        expect(screen.getByText('Bob')).toBeInTheDocument();
    });

    it('filters data with search', async () => {
        const user = userEvent.setup();
        render(<DynamicTable headers={mockHeaders} data={mockData} searchByText={true} />);

        // Initial: All data visible
        expect(screen.getByText('Alice')).toBeInTheDocument();
        expect(screen.getByText('Bob')).toBeInTheDocument();

        // Search for 'Bob'
        const search = await screen.findByTestId('SearchIcon');
        expect(search).toBeInTheDocument();
        await user.click(search);
        const searchInput = screen.getByTestId(/search-input/i); // Assuming Search component has this
        await user.type(searchInput, 'Bob');
        await waitFor(() => {
            expect(screen.getByText('Bob')).toBeInTheDocument();
            expect(screen.queryByText('Alice')).not.toBeInTheDocument();
        });
    });

    it('renders action buttons and calls handlers', async () => {
        const user = userEvent.setup();
        const onView = jest.fn();
        const onEdit = jest.fn();
        const onDelete = jest.fn();
        render(
            <DynamicTable
                headers={mockHeaders}
                data={mockData}
                enableView
                enableEdit
                enableDelete
                onView={onView}
                onEdit={onEdit}
                onDelete={onDelete}
            />
        );

        // Check buttons
        const viewButtons = screen.getAllByText('View');
        expect(viewButtons).toHaveLength(3);

        // Click first View button
        await user.click(viewButtons[0]);
        expect(onView).toHaveBeenCalledWith(mockData[0]);

        // Check buttons
        const editButtons = screen.getAllByText('Edit');
        expect(editButtons).toHaveLength(3);

        // Click first View button
        await user.click(editButtons[0]);
        expect(onEdit).toHaveBeenCalledWith(mockData[0]);

        const deleteButtons = screen.getAllByText('Delete');
        expect(deleteButtons).toHaveLength(3);
        await user.click(deleteButtons[0]);
        expect(onDelete).toHaveBeenCalledWith(mockData[0]);

    });

    it('renders no data message when filteredData is empty', () => {
        render(<DynamicTable headers={mockHeaders} data={[]} />);
        expect(screen.getByText(/does not match our records/i)).toBeInTheDocument();
    });

    it('handles optional features like export and themes', async () => {
        render(
            <DynamicTable
                headers={mockHeaders}
                data={mockData}
                enableExport
                enableThemes
                enableDensePadding
                enableFullScreenOption
            />
        );

        // Check for export button (assuming ExportOptions renders it)
        expect(screen.getByTestId(/FileDownloadIcon/i)).toBeInTheDocument(); // Adjust based on actual rendering

        // Check theme selector (assuming ThemeSelector renders options)
        expect(screen.getByTestId(/PaletteIcon/i)).toBeInTheDocument(); // Adjust as needed

        const fullScreenButton = screen.getByTestId(/FullScreenIcon/i);
        expect(fullScreenButton).toBeInTheDocument();
    });
    it('handles sorting', async () => {
        const user = userEvent.setup();
        const handleSortChange = jest.fn();
        const onPageChangeRequest = jest.fn();
        render(
            <DynamicTable
                headers={mockHeaders}
                data={mockData}
                onPageChangeRequest={onPageChangeRequest}
            />
        );
        const nameSortButton = screen.getByRole('button', { name: /Name/i });
        await user.click(nameSortButton);
        expect(handleSortChange).not.toHaveBeenCalledWith('name');
    });
});