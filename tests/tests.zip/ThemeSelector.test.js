// ThemeSelector.test.tsx
import React from 'react';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ThemeSelector from "../src/ThemeSelector";

describe('ThemeSelector', () => {
    it('renders the palette icon with tooltip', async () => {
        const user = userEvent.setup();
        const handleThemeChange = jest.fn();

        render(<ThemeSelector handleThemeChange={handleThemeChange} />);

        // Tooltip is rendered on hover; but we can still find the icon button by role
        const button = screen.getByRole('button');
        expect(button).toBeInTheDocument();

        // Optionally trigger tooltip hover
        await user.hover(button);
        // Depending on Tooltip configuration, it may or may not render immediately in tests
        // MUI Tooltip uses an aria-hidden element; we can just verify menu behavior on click
    });

    it('opens the menu and lists all themes on click', async () => {
        const user = userEvent.setup();
        const handleThemeChange = jest.fn();

        render(<ThemeSelector handleThemeChange={handleThemeChange} />);

        const button = screen.getByRole('button');
        await user.click(button);

        // The menu should now be open; find it by role
        const menu = await screen.findByRole('menu');
        expect(menu).toBeVisible();

        // Verify menu items
        const items = within(menu).getAllByRole('menuitem');
        const itemLabels = items.map((li) => li.textContent);

        expect(itemLabels).toEqual(["Default",
            "Grey",
            "Blue",
            "Light"]); // capitalized labels
    });

    it('calls handleThemeChange with the selected theme and closes the menu', async () => {
        const user = userEvent.setup();
        const handleThemeChange = jest.fn();

        render(<ThemeSelector handleThemeChange={handleThemeChange} />);

        const button = screen.getByRole('button');
        await user.click(button);

        const menu = await screen.findByRole('menu');
        const oceanItem = within(menu).getByRole('menuitem', { name: 'Blue' });

        await user.click(oceanItem);

        expect(handleThemeChange).toHaveBeenCalledTimes(1);
        expect(handleThemeChange).toHaveBeenCalledWith('blue');

        // Menu should be closed
        expect(menu).not.toBeVisible();
    });

    it('closes the menu without changing theme when pressing Escape', async () => {
        const user = userEvent.setup();
        const handleThemeChange = jest.fn();

        render(<ThemeSelector handleThemeChange={handleThemeChange} />);

        const button = screen.getByRole('button');
        await user.click(button);

        const menu = await screen.findByRole('menu');
        expect(menu).toBeVisible();

        // Press Escape to close
        await user.keyboard('{Escape}');

        expect(menu).not.toBeVisible();
        expect(handleThemeChange).not.toHaveBeenCalled();
    });
});